import Head from "next/head";
import { SpeedInsights } from "@vercel/speed-insights";
import Header from "../components/Header";
import { useState } from "react";

export default function Home() {
  const [email, setEmail] = useState("");

  const handleSubscribe = async () => {
    const res = await fetch("/api/create-subscription", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, priceId: "<YOUR_PRICE_ID>" }),
    });
    const data = await res.json();
    alert("Subscription created! " + JSON.stringify(data));
  };

  return (
    <>
      <Head>
        <title>VoltAir - Power the Future</title>
        <meta name="description" content="VoltAir: wireless energy intelligence ecosystem." />
      </Head>
      <Header />
      <main style={{ padding: "2rem", textAlign: "center" }}>
        <h1>Welcome to VoltAir ⚡</h1>
        <p>Experience the future of wireless energy intelligence.</p>
        <div style={{ marginTop: "2rem" }}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{ padding: "0.5rem", width: "250px" }}
          />
          <button onClick={handleSubscribe} style={{ marginLeft: "1rem", padding: "0.5rem 1rem" }}>
            Subscribe
          </button>
        </div>
        <SpeedInsights url="https://voltair-landing-page.vercel.app" strategy="mobile" />
      </main>
    </>
  );
}