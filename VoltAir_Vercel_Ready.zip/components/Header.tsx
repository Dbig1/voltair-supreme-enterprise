export default function Header() {
  return (
    <header style={{ padding: "1rem", background: "#0f172a", color: "white" }}>
      <img src="/logo.png" alt="VoltAir Logo" style={{ height: "40px" }} />
    </header>
  );
}